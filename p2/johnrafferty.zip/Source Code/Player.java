import java.io.*;

public interface Player{
	int getMove(int[] board) throws IOException;
}