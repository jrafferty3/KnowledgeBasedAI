import java.io.*;
import java.util.Scanner;  
import java.util.Random;

public class Thoughtful implements Player{
	private int playerNumber;
	private int otherNumber;
	private boolean testing;
	public Thoughtful(int number){
		playerNumber = number;
		if(number == 1){
			otherNumber = 2;
		}else{
			otherNumber = 1;
		}
		testing = false;
	}
	
	public Thoughtful(int number, String s){
		playerNumber = number;
		if(number == 1){
			otherNumber = 2;
		}else{
			otherNumber = 1;
		}
		testing = true;
	}
	
	public int getMove(int[] board) throws IOException{
		File infile = new File("thoughtful_db.txt");
		Scanner scan = new Scanner(infile);
		int db_move = 0;
		int[] db = new int[9];
		while(scan.hasNext()){
			String in_board = scan.next();
			String move = scan.next();
			int index = 0;
			for(char c : in_board.toCharArray()){
				if(c=='0'){
					db[index] = 0;
				}else if(c=='!'){
					db[index] = otherNumber;
				}else{
					db[index] = playerNumber;
				}
				index++;
			}
			db_move = Integer.parseInt(move);
			int rot_count = 0;
			while(!equal(db,board) && rot_count < 3){
				db = rotate_b(db);
				rot_count++;
			}
			if(equal(db,board)){
				return unRotate(db_move,rot_count);
			}
		}
		//if run out of db entries with no solution
		//return random
		//if testing ask if good move
		Random rand = new Random();
		db_move = rand.nextInt(9);
		while(board[db_move] != 0){
			db_move = rand.nextInt(9);
		}
		if(testing){
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("What is a good move?");
			try {
				db_move = Integer.parseInt(br.readLine());
			} catch (IOException ioe) {
				System.out.println("IO error trying to read your name!");
				System.exit(1);
			}
			//save board and best move in db
			PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(infile, true)));
			String old_board = toString(board);
			String move = ""+db_move;
			out.println();
			out.println(old_board);
			out.print(move);
			out.close();
		}
		return db_move;
	}
	
	public int[] rotate_b(int[] b){
		int[] ret = {b[6],b[3],b[0],b[7],b[4],b[1],b[8],b[5],b[2]};
		return ret;
	}
	
	public int unRotate(int index, int num_rot){
		int[] zero = new int[9];
		zero[index] = 1;
		for(int i=0;i<num_rot;i++)
			zero = rotate_b(zero);
		int ret = -1;
		for(int i=0;i<zero.length;i++){
			if(zero[i] == 1){
				ret = i;
				break;
			}
		}
		return ret;
	}
	
	public boolean equal(int[] x, int[] y){
		for(int i=0;i<x.length;i++){
			if(x[i] != y[i]){
				return false;
			}
		}
		return true;
	}
	
	public String toString(int[] b){
		String ret = "";
		for(int i=0;i<b.length;i++){
			if(b[i] == 0){
				ret+="0";
			}else if(b[i] == otherNumber){
				ret+="!";
			}else{
				ret+="~";
			}
		}
		return ret;
	}
}